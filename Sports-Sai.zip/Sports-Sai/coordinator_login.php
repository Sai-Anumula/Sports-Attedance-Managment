<?php

$em = $_POST['email'];
$pwd = $_POST['password'];

$servername="localhost";
$username="root";
$password="";
$dbname="sports";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
die("Connection failed:".mysqli_connect_error());
}
#echo("<h1>Connected Sucessfully</h1>");
$sql="select * from student where email='$em' and password='$pwd' and role='coordinator'";
$res=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($res);
if($row==NULL)
{
	echo "<center><h1>Invalid Username or Password</h1><br><a href='coordinator_login.html'>Click me</a>";
}
else 
{
if($row["password"]==$pwd)
{
    setcookie("coordinator", $row["username"], time() + 3600, "/", "", 0);
    echo "<center><h1>Welcome ".$row["username"]."</h1><br><h3><a href='coordinator_dashboard.php'>Start Work</a></h3></center>";
}
else
{
    echo "<h1>Invalid Username or Password</h1><br><a href='coordinator_login.html'>Try again</a></center>";
}
}
mysqli_close($conn);
?>
