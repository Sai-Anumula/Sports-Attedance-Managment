<?php
session_start();

// Check if student is logged in
if (!isset($_COOKIE["student"])) {
    header("Location: student_login.php");
    exit();
}

$student_name = $_COOKIE["student"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            background: url('https://img.freepik.com/premium-photo/abstract-neon-lines-futuristsic-modern_118195-121.jpg') no-repeat center center fixed;
            background-size: cover;
        }
        a {color:pink;}
        </style>
    
</head>
<body>

    <div class="dashboard-container">
        <!-- Welcome Message -->
        <h2 class="welcome-text">Welcome, <?php echo htmlspecialchars($student_name); ?>!</h2>

        <!-- Logout Link -->
        <a href="student_logout.php" class="logout-link">Logout</a>

        <!-- Buttons -->
        <div class="button-container">
            <button onclick="window.location.href='sattendance_summary.php'">Check Attendance Summary</button>
            <button onclick="window.location.href='download_certificate.php'">Download Certificate</button>
        </div>
    </div>

</body>
</html>
