<?php
session_start();

// Remove the student login cookie
setcookie("student", "", time() - 3600, "/", "", 0);

// Redirect to student login page
header("Location: student_login.php");
exit();
?>
