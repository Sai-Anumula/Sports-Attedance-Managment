<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sports"; 

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Initialize variables to prevent warnings
$name = $email = $username = $password = $phone = $department = "";
$error = $success = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = isset($_POST["name"]) ? $_POST["name"] : "";
    $email = isset($_POST["email"]) ? $_POST["email"] : "";
    $username = isset($_POST["username"]) ? $_POST["username"] : "";
    $password = isset($_POST["password"]) ? $_POST["password"] : "";
    $phone = isset($_POST["phone"]) ? $_POST["phone"] : "";
    $department = isset($_POST["department"]) ? $_POST["department"] : "";

    if (!empty($username) && !empty($phone) && !empty($department)) {
        // Check if the username already exists
        $check_query = "SELECT * FROM student WHERE username='$username'";
        $result = mysqli_query($conn, $check_query);

        if (mysqli_num_rows($result) > 0) {
            $error = "Username already exists. Please choose another.";
        } else {
            // Insert student details into the database
            $sql = "INSERT INTO student (name, email, username, password, phone, department) 
                    VALUES ('$name', '$email', '$username', '$password', '$phone', '$department')";

            if (mysqli_query($conn, $sql)) {
                $success = "Registration successful! You can now login.";
            } else {
                $error = "Error: " . mysqli_error($conn);
            }
        }
    } else {
        $error = "All fields are required.";
    }
}
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            background: url('https://img.freepik.com/free-vector/gradient-network-connection-background_23-2148881320.jpg?semt=ais_hybrid') no-repeat center center fixed;
            background-size: cover;
        }
        table {
            border-collapse: collapse;
        }
        table tr td {
            border: none;
            padding: 10px;
        }
    </style>
</head>
<body>
    <center>
    <div class="register-container">
        <h2>Student Registration</h2>
        
        <?php if (!empty($success)) { echo "<p class='success'>$success</p>"; } ?>
        <?php if (!empty($error)) { echo "<p class='error'>$error</p>"; } ?>
        
        <form action="student_register.php" method="POST">
            <table>
                <tr>
                    <td><label for="name">Full Name:</label></td>
                    <td><input type="text" id="name" name="name" placeholder="Enter your full name" required></td>
                </tr>
                <tr>
                    <td><label for="email">Email:</label></td>
                    <td><input type="email" id="email" name="email" placeholder="Enter your email" required></td>
                </tr>
                <tr>
                    <td><label for="username">Username:</label></td>
                    <td><input type="text" id="username" name="username" placeholder="Choose a username" required></td>
                </tr>
                <tr>
                    <td><label for="password">Password:</label></td>
                    <td><input type="password" id="password" name="password" placeholder="Enter your password" required></td>
                </tr>
                <tr>
                    <td><label for="phone">Phone Number:</label></td>
                    <td><input type="text" id="phone" name="phone" placeholder="Enter your phone number" required></td>
                </tr>
                <tr>
                    <td><label for="department">Department:</label></td>
                    <td><input type="text" id="department" name="department" placeholder="Enter your department" required></td>
                </tr>
                <tr>
                    <td colspan="2" style="text-align: center;"><button type="submit">Register</button></td>
                </tr>
            </table>
        </form>
        <p>Already have an account? <a href="student_login.php">Login here</a></p>
    </div>
    </center>
</body>
</html>