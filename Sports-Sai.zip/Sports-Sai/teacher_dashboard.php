<?php
session_start();

// Redirect to login page if not logged in
if (!isset($_COOKIE["uname"])) {
    header("Location: teacher_login.php");
    exit();
}

$teacher_name = $_COOKIE["uname"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body
        {
            
            background: url('https://img.freepik.com/free-photo/abstract-digital-grid-black-background_53876-97647.jpg') no-repeat center center fixed;
            background-size: cover;
            color:white;
        }
        </style>
</head>
<body>

    <div class="dashboard-container">
        <h2 class="welcome-text">Welcome, <?php echo htmlspecialchars($teacher_name); ?>!</h2>
        <a href="teacher_logout.php" class="logout-link">Logout</a>
        
        <div class="button-container">
            <button onclick="window.location.href='students_list.php'">Check Students List</button>  
            <button onclick="window.location.href='make_coordinator.php'">Update Coordinators</button><br>
            <button onclick="window.location.href='coordinator_list.php'">Check Coordinator List</button>  
            <button onclick="window.location.href='presenties_list.php'">Check Presenties List</button><br>
            <button onclick="window.location.href='absentees_list.php'">Check Absentees List</button>  
            <button onclick="window.location.href='tattendance_summary.php'">Check Present & Absentees Count</button><br>
            <button onclick="window.location.href='low_attendance.php'">Check Students (Absent >4 Days)</button><br>
        </div>
    </div>

</body>
</html>
