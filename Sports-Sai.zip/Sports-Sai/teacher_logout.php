<?php
session_start();
session_unset(); 
session_destroy();

setcookie("uname", "", time() - 3600, "/"); // Expire the login cookie

header("Location: teacher_login.php");
exit();
?>
