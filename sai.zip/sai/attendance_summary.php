<?php
session_start();
if (!isset($_COOKIE["coordinator"])) {
    header("Location: coordinator_login.html");
    exit();
}

// Database Connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "sports";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Default values
$day = 1;
$total_students = 0;
$present_count = 0;
$absent_count = 0;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $day = $_POST['day'];

    // Total students count
    $sql_total = "SELECT COUNT(*) AS total FROM student";
    $result_total = $conn->query($sql_total);
    if ($row = $result_total->fetch_assoc()) {
        $total_students = $row['total'];
    }

    // Count Present students
    $sql_present = "SELECT COUNT(*) AS present FROM attendance WHERE day='$day' AND status='Present'";
    $result_present = $conn->query($sql_present);
    if ($row = $result_present->fetch_assoc()) {
        $present_count = $row['present'];
    }

    // Count Absent students
    $sql_absent = "SELECT COUNT(*) AS absent FROM attendance WHERE day='$day' AND status='Absent'";
    $result_absent = $conn->query($sql_absent);
    if ($row = $result_absent->fetch_assoc()) {
        $absent_count = $row['absent'];
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Summary</title>
    <style>
        body { background: url('https://img.freepik.com/free-vector/abstract-technology-particles-low-poly-background_1017-23831.jpg?semt=ais_hybrid') no-repeat center center fixed;
            background-size: cover;
        }
        a {color:pink;}
        h2 { margin-bottom: 20px; }
        form { margin-bottom: 20px; }
        table { width: 50%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid black; padding: 10px; text-align: center; }
        th { background-color: #f2f2f2; }
        button { padding: 10px 20px; margin-top: 10px; }
    </style>
</head>
<body>

    <a href="coordinator_logout.php" style="float: right;">Logout</a>
    <h2>Attendance Summary</h2>

    <form method="post">
        <label for="day">Select Day:</label>
        <select name="day" id="day">
            <?php for ($i = 1; $i <= 15; $i++) { 
                echo "<option value='$i' " . ($day == $i ? "selected" : "") . ">Day $i</option>"; 
            } ?>
        </select>
        <button type="submit">View Summary</button>
    </form>

    <table>
        <tr>
            <th>Total Students</th>
            <th>Present Count</th>
            <th>Absent Count</th>
        </tr>
        <tr>
            <td><?php echo $total_students; ?></td>
            <td><?php echo $present_count; ?></td>
            <td><?php echo $absent_count; ?></td>
        </tr>
    </table>
    
    <a href="coordinator_dashboard.php">Go Back to Dashboard</a>

</body>
</html>
