<?php
session_start();
if (!isset($_COOKIE["coordinator"])) {
    header("Location: coordinator_login.html");
    exit();
}

$coordinator_name = $_COOKIE["coordinator"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coordinator Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body { background: url('https://media.istockphoto.com/id/2010363452/photo/the-structure-of-the-transmission-of-musical-sounds-abstract-background-of-running-luminous.webp?b=1&s=612x612&w=0&k=20&c=vtJ5ahaXjUsWyXRSDM56-TsOYHtrQ-_7svb1xS2CrIw=') no-repeat center center fixed;
            background-size: cover;
            color:white;
        }
        </style>
    
</head>
<body>

    <div class="dashboard-container">
        <h2 class="welcome-text">Welcome, <?php echo htmlspecialchars($coordinator_name); ?>!</h2>
        <a href="coordinator_logout.php" class="logout-link">Logout</a>

        <div class="button-container">
            <button onclick="window.location.href='take_attendance.php'">Take Attendance</button>
            <button onclick="window.location.href='attendance_summary.php'">Check Attendance Summary</button>
        </div>
    </div>

</body>
</html>
