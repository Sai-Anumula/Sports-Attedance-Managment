<?php
session_start();
setcookie("coordinator", "", time() - 3600, "/", "", 0);
header("Location: coordinator_login.html");
exit();
?>
