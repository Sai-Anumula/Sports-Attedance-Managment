<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sports";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $username = $_POST["username"];
    $password = $_POST["password"];
    $department = $_POST["department"];
    $phone = $_POST["phone"];

    // Check if username or email already exists
    $check_sql = "SELECT * FROM coordinator WHERE username='$username' OR email='$email'";
    $check_result = mysqli_query($conn, $check_sql);

    if (mysqli_num_rows($check_result) > 0) {
        $error = "Username or Email already exists!";
    } else {
        $sql = "INSERT INTO coordinator (name, email, username, password, department, phone) 
                VALUES ('$name', '$email', '$username', '$password', '$department', '$phone')";

        if (mysqli_query($conn, $sql)) {
            $success = "Registration successful! <a href='coordinator_login.php'>Login here</a>";
        } else {
            $error = "Error: " . mysqli_error($conn);
        }
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coordinator Registration</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <div class="register-container">
        <h2>Coordinator Registration</h2>

        <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>
        <?php if (!empty($success)) echo "<p class='success'>$success</p>"; ?>

        <form action="coordinator_register.php" method="POST">
            <label>Name:</label>
            <input type="text" name="name" required>

            <label>Email:</label>
            <input type="email" name="email" required>

            <label>Username:</label>
            <input type="text" name="username" required>

            <label>Password:</label>
            <input type="password" name="password" required>

            <label>Department:</label>
            <input type="text" name="department" required>

            <label>Phone:</label>
            <input type="text" name="phone" required>

            <button type="submit">Register</button>
        </form>

        <p>Already registered? <a href="coordinator_login.php">Login here</a></p>
    </div>

</body>
</html>
