<?php
session_start();

// Redirect to login page if not logged in
if (!isset($_COOKIE["student"])) {
    header("Location: student_login.php");
    exit();
}

// Database Connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "sports";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$student_name = $_COOKIE["student"];
$student_id = null;
$absent_days = 0;

// Fetch student ID
$sql_student = "SELECT id FROM student WHERE username = ?";
$stmt = $conn->prepare($sql_student);
$stmt->bind_param("s", $student_name);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $student_id = $row['id'];
}
$stmt->close();

// Fetch absent days count
if ($student_id) {
    $sql_absent = "SELECT COUNT(*) AS absent_days FROM attendance WHERE student_id = ? AND status = 'Absent'";
    $stmt = $conn->prepare($sql_absent);
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $absent_days = $row['absent_days'];
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Download Certificate</title>
    <style>
        body {
            font-family: "Lucida Bright", serif;
            text-align: center;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            <?php if ($absent_days <= 4): ?>
                background-image: url('https://img.freepik.com/premium-vector/blue-gold-geometry-modern-certificate-border-frame_257504-424.jpg?semt=ais_hybrid');
            <?php else: ?>
                background-color: #f8f8f8;
            <?php endif; ?>
        }

        .certificate-container {
            padding: 50px;
            background: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            width: 60%;
            <?php if ($absent_days > 4): ?>
                box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            <?php endif; ?>
        }

        h1 {
            font-size: 40px;
            color: #003366;
            margin-bottom: 20px;
        }

        .message {
            font-size: 20px;
            color: #cc0000;
            font-weight: bold;
        }

        .student-name {
            font-size: 30px;
            font-weight: bold;
            margin-top: 20px;
            color: #333;
        }
    </style>
</head>
<body>

    <div class="certificate-container">
        <?php if ($absent_days > 4): ?>
            <h1>Sorry!</h1>
            <p class="message">You didn't get the certificate due to more than 4 absences.</p>
        <?php else: ?>
            <h1>Certificate of Completion</h1>
            <p class="student-name"><?php echo htmlspecialchars($student_name); echo "<br><h3>You have succesfully completed KHO-KHO Sports certification of 15 days</h3>";?></p>
        <?php endif; ?>
    </div>

</body>
</html>
