<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index Page</title>
    <link rel="stylesheet" href="styles.css">
   <style>
     body { background: url('https://i.pinimg.com/736x/98/23/94/982394489161e30ee15f72b9ce443bb2.jpg') no-repeat center center fixed;
            background-size: cover;
            color:white;
     }
     h1 
     {
        color:yellow;
     }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome</h1>
        <div class="profiles">
            <div class="profile">
                <img src="teacher.png" alt="Teacher">
                <h2>Teacher</h2>
                <a href="teacher_login.php" class="btn">Login</a>
            </div>
            <div class="profile">
                <img src="student.png" alt="Student">
                <h2>Student</h2>
                <a href="student_register.php" class="btn">Register</a>
                <a href="student_login.php" class="btn">Login</a>
            </div>
            <div class="profile">
                <img src="coordinator.png" alt="Coordinator">
                <h2>Coordinator</h2>
                <a href="coordinator_login.html" class="btn">Login</a>
            </div>
        </div>
    </div>
</body>
</html>
