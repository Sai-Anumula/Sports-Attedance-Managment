<?php
session_start();

// Redirect to login page if not logged in
if (!isset($_COOKIE["uname"])) {
    header("Location: teacher_login.php");
    exit();
}

// Database Connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "sports";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch students who were absent more than 4 days
$sql_low_attendance = "SELECT student.id, student.name, COUNT(attendance.id) AS absent_days
                       FROM student 
                       LEFT JOIN attendance ON student.id = attendance.student_id 
                       AND attendance.status = 'Absent'
                       GROUP BY student.id, student.name
                       HAVING absent_days > 4";

$result = $conn->query($sql_low_attendance);

$low_attendance_students = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $low_attendance_students[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Low Attendance Students</title>
    <style>
        body { background: url('https://img.freepik.com/free-photo/technology-abstract-background-with-particle-lines_53876-104054.jpg') no-repeat center center fixed;
            background-size: cover;
            color:white;
            font-family: Arial, sans-serif; margin: 20px; text-align: center; }

        h2 { margin-bottom: 20px; }
        form { margin-bottom: 20px; }
        table { width: 50%; margin: auto; border-collapse: collapse; margin-top: 20px; }
        th { border: 1px solid black; padding: 10px; text-align: center; color:black;}
        td { border: 1px solid black; padding: 10px; text-align: center; color:white;}
        th { background-color: #f2f2f2; }
        button { padding: 10px 20px; margin-top: 20px; cursor: pointer; }
        a {color:pink;}
    </style>
</head>
<body>

    <a href="teacher_logout.php" style="float: right;">Logout</a>
    <h2>Students with Low Attendance (Absent > 4 Days)</h2>

    <table>
        <tr>
            <th>#</th>
            <th>Student Name</th>
            <th>Absent Days</th>
        </tr>
        <?php 
        if (!empty($low_attendance_students)) {
            $count = 1;
            foreach ($low_attendance_students as $student) {
                echo "<tr>
                        <td>$count</td>
                        <td>" . htmlspecialchars($student['name']) . "</td>
                        <td>" . $student['absent_days'] . "</td>
                      </tr>";
                $count++;
            }
        } else {
            echo "<tr><td colspan='3'>No students have more than 4 absences.</td></tr>";
        }
        ?>
    </table>

    <button onclick="window.location.href='teacher_dashboard.php'">Back to Dashboard</button>

</body>
</html>
