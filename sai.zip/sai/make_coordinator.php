<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sports";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the teacher is logged in
if (!isset($_COOKIE["uname"])) {
    header("Location: teacher_login.php");
    exit();
}

// Handle promotions and depromotions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = mysqli_real_escape_string($conn, $_POST["student_id"]);

    if (isset($_POST["promote"])) {
        // Promote to coordinator
        $update_query = "UPDATE student SET role = 'coordinator' WHERE id = $student_id";
        mysqli_query($conn, $update_query);
        $message = (mysqli_affected_rows($conn) > 0) ? "Student promoted to coordinator successfully!" : "Error promoting student or no change made.";
    } elseif (isset($_POST["depromote"])) {
        // Depromote to student
        $update_query = "UPDATE student SET role = 'student' WHERE id = $student_id";
        mysqli_query($conn, $update_query);
        $message = (mysqli_affected_rows($conn) > 0) ? "Coordinator depromoted to student successfully!" : "Error depromoting coordinator or no change made.";
    }
}

// Fetch students who can be promoted
$sql_students = "SELECT * FROM student WHERE role = 'student'";
$result_students = mysqli_query($conn, $sql_students);

// Fetch coordinators who can be depromoted
$sql_coordinators = "SELECT * FROM student WHERE role = 'coordinator'";
$result_coordinators = mysqli_query($conn, $sql_coordinators);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Coordinators</title>
    <link rel="stylesheet" href="styles.css">
    <style>
         body
        {
            background: url('https://img.freepik.com/free-vector/geometric-gradient-futuristic-background_23-2149116406.jpg?semt=ais_hybrid') no-repeat center center fixed;
            background-size: cover;
            color:white;
        }
        a
        {
            color:pink;
        }
        </style>
</head>
<body>
<center>
    <div class="container">
        <h2>Manage Coordinators</h2>

        <?php if (isset($message)): ?>
            <p class="success"><?php echo htmlspecialchars($message); ?></p>
        <?php endif; ?>

        <!-- Promote Students to Coordinators -->
        <h3>Promote Students to Coordinators</h3>
        <?php if (mysqli_num_rows($result_students) > 0): ?>
            <table border=1>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Department</th>
                    <th>Action</th>
                </tr>
                <?php while ($row = mysqli_fetch_assoc($result_students)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row["id"]); ?></td>
                        <td><?php echo htmlspecialchars($row["name"]); ?></td>
                        <td><?php echo htmlspecialchars($row["department"]); ?></td>
                        <td>
                            <form action="make_coordinator.php" method="POST">
                                <input type="hidden" name="student_id" value="<?php echo htmlspecialchars($row["id"]); ?>">
                                <button type="submit" name="promote">Promote</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </table>
        <?php else: ?>
            <p>No students available for promotion.</p>
        <?php endif; ?>

        <!-- Depromote Coordinators to Students -->
        <h3>Depromote Coordinators to Students</h3>
        <?php if (mysqli_num_rows($result_coordinators) > 0): ?>
            <table border=1>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Department</th>
                    <th>Action</th>
                </tr>
                <?php while ($row = mysqli_fetch_assoc($result_coordinators)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row["id"]); ?></td>
                        <td><?php echo htmlspecialchars($row["name"]); ?></td>
                        <td><?php echo htmlspecialchars($row["department"]); ?></td>
                        <td>
                            <form action="make_coordinator.php" method="POST">
                                <input type="hidden" name="student_id" value="<?php echo htmlspecialchars($row["id"]); ?>">
                                <button type="submit" name="depromote">Depromote</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </table>
        <?php else: ?>
            <p>No coordinators available for depromotion.</p>
        <?php endif; ?>

        <a href="teacher_dashboard.php">Back to Dashboard</a>
    </div>
        </center>
</body>
</html>

<?php mysqli_close($conn); ?>
