<?php
session_start();

// Redirect to login page if not logged in
if (!isset($_COOKIE["uname"])) {
    header("Location: teacher_login.php");
    exit();
}

// Database Connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "sports";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Default values
$day = 1;
$present_students = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $day = $_POST['day'];

    // Fetch list of students who were present on the selected day
    $sql_present = "SELECT student.name FROM attendance 
                    INNER JOIN student ON attendance.student_id = student.id
                    WHERE attendance.day = ? AND attendance.status = 'Present'";
    
    $stmt = $conn->prepare($sql_present);
    $stmt->bind_param("i", $day);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $present_students[] = $row['name'];
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Present Students List</title>
    <!--<link rel="stylesheet" href="styles.css">
    <style>
        .btn 
        {
            width:200px;
        }
        body
        {
            background: url('https://png.pngtree.com/background/20210715/original/pngtree-abstract-background-work-technology-picture-image_1316469.jpg') no-repeat center center fixed;
            background-size: cover;
            color:white;
        }
        </style>-->
    <style>
        body { background: url('https://hotemailtemplates.com/templates/Free/wallpapers/1680x1050/Glowing%20Background.jpg') no-repeat center center fixed;
            background-size: cover;
            color:white;
            font-family: Arial, sans-serif; margin: 20px; text-align: center; }

        h2 { margin-bottom: 20px; }
        form { margin-bottom: 20px; }
        table { width: 50%; margin: auto; border-collapse: collapse; margin-top: 20px; }
        th { border: 1px solid black; padding: 10px; text-align: center; color:black;}
        td { border: 1px solid black; padding: 10px; text-align: center; color:white;}
        th { background-color: #f2f2f2; }
        button { padding: 10px 20px; margin-top: 20px; cursor: pointer; }
    </style>
</head>
<body>

    <a href="teacher_logout.php" style="float: right;">Logout</a>
    <h2>Present Students List</h2>

    <form method="post">
        <label for="day">Select Day:</label>
        <select name="day" id="day">
            <?php for ($i = 1; $i <= 15; $i++) { 
                echo "<option value='$i' " . ($day == $i ? "selected" : "") . ">Day $i</option>"; 
            } ?>
        </select>
        <button type="submit">View List</button>
    </form>

    <table>
        <tr>
            <th>#</th>
            <th>Student Name</th>
        </tr>
        <?php 
        if (!empty($present_students)) {
            $count = 1;
            foreach ($present_students as $student) {
                echo "<tr><td>$count</td><td>" . htmlspecialchars($student) . "</td></tr>";
                $count++;
            }
        } else {
            echo "<tr><td colspan='2'>No students were present on Day $day.</td></tr>";
        }
        ?>
    </table>

    <button onclick="window.location.href='teacher_dashboard.php'">Back to Dashboard</button>

</body>
</html>
