<?php
session_start();

// Check if student is logged in
if (!isset($_COOKIE["student"])) {
    header("Location: student_login.php");
    exit();
}

// Get student name from cookie
$student_name = $_COOKIE["student"];

// Database Connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "sports";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get student ID using the name from the cookie
$sql_student = "SELECT id FROM student WHERE username = ?";
$stmt = $conn->prepare($sql_student);
$stmt->bind_param("s", $student_name);
$stmt->execute();
$result = $stmt->get_result();
$student_id = null;

if ($row = $result->fetch_assoc()) {
    $student_id = $row['id'];
}
$stmt->close();

// If student not found, redirect to login
if (!$student_id) {
    header("Location: student_login.php");
    exit();
}

// Fetch attendance data
$total_days = 15;

// Count Present Days
$sql_present = "SELECT COUNT(*) AS present FROM attendance WHERE student_id = ? AND status = 'Present'";
$stmt = $conn->prepare($sql_present);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();
$present_days = ($row = $result->fetch_assoc()) ? $row['present'] : 0;
$stmt->close();

// Count Absent Days
$sql_absent = "SELECT COUNT(*) AS absent FROM attendance WHERE student_id = ? AND status = 'Absent'";
$stmt = $conn->prepare($sql_absent);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();
$absent_days = ($row = $result->fetch_assoc()) ? $row['absent'] : 0;
$stmt->close();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Summary</title>
    <style>
        body { background: url('https://e0.pxfuel.com/wallpapers/914/200/desktop-wallpaper-black-abstract-windows-8-1-all-for-windows-10-html.jpg') no-repeat center center fixed;
            background-size: cover;
            color:white;
            font-family: Arial, sans-serif; margin: 20px; text-align: center; }

        h2 { margin-bottom: 20px; }
        form { margin-bottom: 20px; }
        table { width: 50%; margin: auto; border-collapse: collapse; margin-top: 20px; }
        th { border: 1px solid black; padding: 10px; text-align: center; color:black;}
        td { border: 1px solid black; padding: 10px; text-align: center; color:white;}
        th { background-color: #f2f2f2; }
        button { padding: 10px 20px; margin-top: 20px; cursor: pointer; }
        a {color:pink;}
    </style>
</head>
<body>

    <a href="student_logout.php" style="float: right;">Logout</a>
    <h2>Attendance Summary for <?php echo htmlspecialchars($student_name); ?></h2>

    <table>
        <tr>
            <th>Total Days</th>
            <th>Present Days</th>
            <th>Absent Days</th>
        </tr>
        <tr>
            <td><?php echo $total_days; ?></td>
            <td><?php echo $present_days; ?></td>
            <td><?php echo $absent_days; ?></td>
        </tr>
    </table>

    <button onclick="window.location.href='student_dashboard.php'">Back to Dashboard</button>

</body>
</html>
