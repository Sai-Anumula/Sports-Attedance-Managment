<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sports";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$error = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = isset($_POST["username"]) ? $_POST["username"] : "";
    $password = isset($_POST["password"]) ? $_POST["password"] : "";

    if (!empty($username) && !empty($password)) {
        // Check student credentials
        $sql = "SELECT * FROM student WHERE username='$username'";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($result);

        if ($row && $row["password"] == $password) {
            setcookie("student", $username, time() + 3600, "/", "", 0);
            header("Location: student_dashboard.php");
            exit();
        } else {
            $error = "Invalid Username or Password.";
        }
    } else {
        $error = "Please fill in all fields.";
    }
}
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Login</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            background: url('https://t3.ftcdn.net/jpg/09/58/19/62/360_F_958196252_wipveBpnyzFPRVG7cXw3NZuRLanW6nJh.jpg') no-repeat center center fixed;
            background-size: cover;
        }
        a {color:pink;}
        </style>
</head>
<body>

    <div class="login-container">
        <h2>Student Login</h2>

        <?php if (!empty($error)) { echo "<p class='error'>$error</p>"; } ?>

        <form action="student_login.php" method="POST">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required><br><br>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required><br><br>

            <button type="submit">Login</button>
        </form>

        <p>Don't have an account? <a href="student_register.php">Register here</a></p>
    </div>

</body>
</html>
