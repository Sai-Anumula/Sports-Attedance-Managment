<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sports";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the teacher is logged in
if (!isset($_COOKIE["uname"])) {
    header("Location: teacher_login.php");
    exit();
}

// Fetch students
$sql = "SELECT * FROM student";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students List</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        h2{
color:white;
        }
        .btn 
        {
            width:200px;
        }
        body
        {
            background: url('https://img.freepik.com/premium-vector/glowing-neon-abstract-futuristic-hitech-background_88343-16702.jpg') no-repeat center center fixed;
            background-size: cover;
            color:white;
        }
        </style>
</head>
<body>

    <div class="container">
        <h2>Students List</h2>
        <center>
        <?php if (mysqli_num_rows($result) > 0): ?>
            <table border=1>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Department</th>
                    <th>Role</th>
                </tr>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo $row["id"]; ?></td>
                        <td><?php echo $row["name"]; ?></td>
                        <td><?php echo $row["email"]; ?></td>
                        <td><?php echo $row["phone"]; ?></td>
                        <td><?php echo $row["department"]; ?></td>
                        <td><?php echo ucfirst($row["role"]); ?></td>
                    </tr>
                <?php endwhile; ?>
            </table>
        <?php else: ?>
            <p>No students found.</p>
        <?php endif; ?>

        <a href="teacher_dashboard.php" class="btn">Back to Dashboard</a>
    </div>
        </center>
</body>
</html>

<?php mysqli_close($conn); ?>
