<?php
session_start();
if (!isset($_COOKIE["coordinator"])) {
    header("Location: coordinator_login.html");
    exit();
}

// Database Connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "sports";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle Form Submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $day = $_POST['day'];
    $attendance = $_POST['attendance'];

    foreach ($attendance as $student_id => $status) {
        $sql = "INSERT INTO attendance (student_id, day, status, date) 
                VALUES ('$student_id', '$day', '$status', NOW())
                ON DUPLICATE KEY UPDATE status='$status', date=NOW()";

        if (!$conn->query($sql)) {
            echo "<script>alert('Error: " . $conn->error . "');</script>";
        }
    }

    echo "<script>alert('Attendance recorded successfully!'); window.location.href='take_attendance.php';</script>";
}

// Fetch Students
$sql = "SELECT id, name FROM student";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Take Attendance</title>
    <style>
        
        body { background: url('https://t3.ftcdn.net/jpg/12/28/88/02/360_F_1228880261_HkD6jux0Kl1Tke47PdRcIUIr6Gk1uqdF.jpg') no-repeat center center fixed;
            background-size: cover;font-family: Arial, sans-serif; margin: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid black; padding: 10px; text-align: left; }
        th { background-color: #f2f2f2; }
        a{color:pink;}
        button { padding: 10px 20px; margin-top: 20px; }
    </style>
</head>
<body>

    <a href="coordinator_logout.php" style="float: right;">Logout</a>
    <h2>Take Attendance</h2>

    <form method="post">
        <label for="day">Choose Day:</label>
        <select name="day" id="day">
            <?php for ($i = 1; $i <= 15; $i++) { echo "<option value='$i'>Day $i</option>"; } ?>
        </select>

        <table>
            <tr>
                <th>Student Name</th>
                <th>Attendance</th>
            </tr>
            <?php 
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                    echo "<td>
                        <input type='radio' name='attendance[".$row['id']."]' value='Present' required> Present
                        <input type='radio' name='attendance[".$row['id']."]' value='Absent'> Absent
                    </td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='2'>No students found.</td></tr>";
            }
            ?>
        </table>

        <button type="submit">Submit Attendance</button>
    </form>
    
    <a href="coordinator_dashboard.php">Go Back to Dashboard</a>

</body>
</html>

<?php $conn->close(); ?>
