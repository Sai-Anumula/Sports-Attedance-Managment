<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $uname = $_POST['username'];
    $pwd = $_POST['password'];

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "sports";

    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Fetch teacher details based on case-sensitive username
    $sql = "SELECT * FROM teacher WHERE BINARY username='$uname'";
    $res = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($res);

    if ($row == NULL || strcmp($row["password"], $pwd) !== 0) {
        $error = "Invalid Username or Password!";
    } else {
        setcookie("uname", $uname, time() + 3600, "/", "", 0);
        header("Location: teacher_dashboard.php"); // Redirect to dashboard
        exit();
    }

    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Login</title>
    <style>
        body {
            background: url('https://img.freepik.com/free-vector/futuristic-background-design_23-2148503793.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: "Lucida Calligraphy", cursive;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            flex-direction: column;
            margin: 0;
            color:white;
        }
        input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .btn {
            background: #5c67f2;
            color: white;
            border: none;
            padding: 10px;
            width: 100%;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .btn:hover {
            background: #434db8;
        }
        h1 {
            margin-bottom: 20px;
        }
    </style>

</head>
<body>

    <div class="login-container">
        <h2>Teacher Login</h2>

        <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>

        <form method="POST" action="teacher_login.php">
            <label for="username">Username:</label>
            <input type="text" name="username" id="username" required>
<br><br>
            <label for="password">Password:</label>
            <input type="password" name="password" id="password" required>
<br><br>
            <button type="submit">Login</button>
        </form>

        <a href="index.php">Back to Home</a>
    </div>

</body>
</html>
